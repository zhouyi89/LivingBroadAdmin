let obj = {
  attribution: '© 版权所有 2015-2017 无锡路通视信网络股份有限公司'
}
export default obj