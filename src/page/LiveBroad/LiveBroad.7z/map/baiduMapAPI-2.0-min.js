export default window.BMap
